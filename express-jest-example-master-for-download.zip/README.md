![Node.js CI](https://github.com/StephenDavidson/express-jest-example/workflows/Node.js%20CI/badge.svg)
# express-jest-example
Example of jest running with an express REST api

# setup

`npm i`

# run tests

`npm test`

# autowatch

`npm run test:watch`
